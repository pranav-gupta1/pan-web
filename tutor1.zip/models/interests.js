const mongoose = require('mongoose');

const interestListSchema = new mongoose.Schema({
    
})